package com.testautomation.stepDef;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TejaswiStepDef {
	@Given("^browser open$")
	public void browser_open() {
		System.out.println("message for browser open");
	}
	
	@When("^print a message$")
	public void print_a_message() {
		System.out.println("test message");
	}
	
	@Then("^close test$")
	public void close_test() {
		System.out.println("close test");
	}	
}
