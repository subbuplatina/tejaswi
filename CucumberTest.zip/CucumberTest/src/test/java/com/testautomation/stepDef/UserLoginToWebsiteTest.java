package com.testautomation.stepDef;

import org.junit.Assert;


import com.cucumber.listener.Reporter;
import com.testautomation.PageObjects.HomePage;
import com.testautomation.PageObjects.LogOutPage;
import com.testautomation.PageObjects.LoginPage;
import com.testautomation.Utility.BaseTest;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserLoginToWebsiteTest extends BaseTest {

	LoginPage loginpage;

	/*@Before
	public void OpenBrowser() {
		BaseTest.intialization();
		Reporter.assignAuthor("Test Automation");
	}*/

	@Given("^I am on amazon login page$")
	public void i_am_on_amazon_login_page() throws Throwable {

		new HomePage().NavigateToHomePage();
	}

	@When("^I login to website with valid user$")
	public void i_login_to_website_with() throws Throwable {

		loginpage = new LoginPage();
		loginpage.LoginToApp();
	}

	@Then("^I see a welcome user message$")
	public void i_see_a_welcome_user_message() throws Throwable {

		loginpage.LoginArrival();
	}

	@When("^I logout from the website$")
	public void i_logout_from_the_website() throws Throwable {

		new LogOutPage().Logout();
	}

	@Then("^I see a logout page \"([^\"]*)\"$")
	public void i_see_a_logout_page(String Title) throws Throwable {

		String ActualTitle = new LogOutPage().LogoutValidation();
		String expected = Title;
		Assert.assertEquals("expected test not matching with actual", expected, ActualTitle);
	}

	/*@After
	public void tearDown(Scenario scenario) {
		if (scenario.isFailed()) {
			String screenshotName = scenario.getName().replaceAll(" ", " _");
			BaseTest.captureScreen(screenshotName);
		}
		BaseTest.closeDriver();
		Reporter.setSystemInfo("User Name", System.getProperty("user.name"));
		Reporter.setSystemInfo("Time Zone", System.getProperty("user.timezone"));
		Reporter.setSystemInfo("Machine", "Windows 10" + "64 Bit");
		Reporter.setSystemInfo("Selenium", "3.7.0");
		Reporter.setSystemInfo("Maven", "3.5.2");
		Reporter.setSystemInfo("Java Version", "1.8.0_151");
	}*/

}
