package com.testautomation.stepDef;

import com.testautomation.PageObjects.HomePage;
import com.testautomation.PageObjects.searchPage;
import com.testautomation.Utility.JsonDataReader;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class UserSearchForProduct {

	@Given("^I am on amazon Sign In Page$")
	public void i_am_on_amazon_Sign_In_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		new HomePage().NavigateToHomePage();

	}

	@When("^I search for my books$")
	public void i_search_for_books() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		String books = new JsonDataReader().getCustomerBooksToSearch();
		new searchPage().NavigateToResultsPage(books);

	}

	@Then("^I see results Page$")
	public void i_see_results_Page() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		new searchPage().resultsPage();

	}

}
