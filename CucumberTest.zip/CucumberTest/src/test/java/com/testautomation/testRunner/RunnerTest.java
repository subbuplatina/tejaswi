package com.testautomation.testRunner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/resources/myFeatures", plugin = {
		"com.cucumber.listener.ExtentCucumberFormatter:cucumberFolder/cucumber-reports/report.html" }, tags = {
				"@sample"}, glue = { "com.testautomation.stepDef" })
public class RunnerTest {

}
