package com.testautomation.PageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import com.testautomation.Utility.BaseTest;

public class resultsPage extends BaseTest{
		
	public resultsPage() {

		PageFactory.initElements(driver, this);
	}
	
	@FindBy(how=How.ID,using="search")
	public WebElement SearchTextBox3;
	
		
	public String getPageTitle() {
		return driver.getTitle();
	}
		
}


