package com.testautomation.PageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.testautomation.Utility.BaseTest;

public class HomePage extends BaseTest{
	public HomePage() {

		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath=".//*[@id='nav-link-yourAccount']/span[1]")
	public WebElement LinkAccount;
	
	@FindBy(xpath=".//*[@id='nav-flyout-ya-signin']/a/span")
	public WebElement SignInButton;
	
	
	@FindBy(xpath=".//*[@id='ap_email']")
	public WebElement EmailTextBox;
	
	@FindBy(xpath=".//*[@id='continue']")
	public WebElement ContinueButton;
	
	@FindBy(xpath=".//*[@id='ap_password']")
	public WebElement PassWordTextBox;
	
	@FindBy(xpath=".//*[@id='signInSubmit']")
	public WebElement LoginButton;
	
	
		
	public String getPageTitle() {
		return driver.getTitle();
	}
	
	public void NavigateToHomePage() throws InterruptedException {
		elementClick(LinkAccount,"clicked on Account link");		
	}

}
