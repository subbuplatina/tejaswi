package com.testautomation.PageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.testautomation.Utility.BaseTest;

public class LogOutPage extends BaseTest {
	public LogOutPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = ".//*[@id='ap_email']")
	public WebElement EmailTextBox;
	@FindBy(xpath = ".//*[@id='nav-item-signout']/span")
	public WebElement SignOutLink;
	@FindBy(xpath = ".//*[@id='nav-link-yourAccount']/span[1]")
	public WebElement LinkAccount1;

	public void Logout() throws InterruptedException {
		mouseHover(LinkAccount1);
		elementClick(SignOutLink, "Clicked on Signout Link");
	}

	public String LogoutValidation() throws InterruptedException {

		waitForPresenceOfElement(By.xpath(".//*[@id='ap_email']"));
		return driver.getTitle();
	}
}
