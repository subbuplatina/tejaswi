package com.testautomation.PageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.testautomation.Utility.BaseTest;
import com.testautomation.Utility.JsonDataReader;

public class LoginPage extends BaseTest {
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = ".//*[@id='ap_email']")
	public WebElement EmailTextBox;
	@FindBy(xpath = ".//*[@id='continue']")
	public WebElement ContinueButton;
	@FindBy(xpath = ".//*[@id='ap_password']")
	public WebElement PassWordTextBox;
	@FindBy(xpath = ".//*[@id='signInSubmit']")
	public WebElement LoginButton;
	@FindBy(xpath = ".//*[@id='nav-link-yourAccount']/span[1]")
	public WebElement LinkAccount1;

	public void LoginToApp() throws InterruptedException {
		
		String email = new JsonDataReader().getCustomerEmail();
		elementSendKeysWithClear(EmailTextBox, email,"username entered");
		elementClick(ContinueButton,"clicked on continue button");
		String pwd = getPassword();
		elementSendKeysWithClear(PassWordTextBox, pwd,"password entered");
		elementClick(LoginButton,"clicked on Login button");
	}

	public void LoginArrival() throws InterruptedException {		
		waitForTextToPresent(LinkAccount1, "Hello, pravin");		
	}
}
