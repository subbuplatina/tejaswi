package com.testautomation.PageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.testautomation.Utility.BaseTest;

public class searchPage extends BaseTest {
	// initializing page objects
	public searchPage() {
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = ".//*[@id='twotabsearchtextbox']")
	public WebElement SearchTextBox;

	@FindBy(xpath = ".//*[@type='submit']")
	public WebElement SubmitButon;

	@FindBy(id = "s-result-count")
	public WebElement resultsCount;

	public void NavigateToResultsPage(String books) throws InterruptedException {

		elementSendKeysWithClear(SearchTextBox, books, "Entered data to search");
		elementClick(SubmitButon, "Clicked on submit button");

	}

	public void resultsPage() throws InterruptedException {
		waitForVisibilityOfElement(resultsCount);
	}

}
