package com.testautomation.Utility;

public class UserProfile {

	public String emailAddress;
public String books;
public String firstname;

public String getEmailAddress() {
return emailAddress;
}

public void setEmailAddress(String emailAddress) {
this.emailAddress = emailAddress;
}

public String getBooks() {
return books;
}

public void setBooks(String books) {
this.books = books;
}

public String getFirstname() {
return firstname;
}

public void setFirstname(String firstname) {
this.firstname = firstname;
}

}