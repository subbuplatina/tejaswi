package com.testautomation.Utility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropFileReader {
   Properties prop;
	public Properties getProperty() throws IOException{
		Properties prop = new Properties();
		try {
			prop.load(new FileInputStream("src/main/resources/Configuration.properties"));
		}catch(Exception e){
			System.out.println("Exception: " + e);
		}
		return prop;

	}
	public String getReportConfigPath(){
		String reportConfigPath = prop.getProperty("reportConfigPath");
		if(reportConfigPath!= null) return reportConfigPath;
		else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath");		
	}
	
	

}
