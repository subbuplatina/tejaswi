package com.testautomation.Utility;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;

import com.google.gson.Gson;


public class JsonDataReader {
	Properties prop = new Properties();
	public String customerFilePath = BaseTest.getTestDataResourcePath()+"UserProfile.json";
	private List<UserProfile> customerList;

public JsonDataReader(){
customerList = getCustomerData();
}

private List<UserProfile> getCustomerData() {
	Gson gson = new Gson();
	BufferedReader bufferReader = null;
	try {
		bufferReader = new BufferedReader(new FileReader(customerFilePath));
		UserProfile[] customers = gson.fromJson(bufferReader, UserProfile[].class);
		return Arrays.asList(customers);
	}catch(FileNotFoundException e) {
		throw new RuntimeException("Json file not found at path : " + customerFilePath);
	}finally {
	try { 
		if(bufferReader != null) bufferReader.close();
		}
	catch (IOException ignore) {}
	}
}

public final UserProfile getCustomerByName(String customerName){
	for(UserProfile customer : customerList) {
		if(customer.firstname.equalsIgnoreCase(customerName)) return customer;
	}
	return null;
}

public String getCustomerEmail(){
	for(UserProfile customer : customerList) {
		if(customer.firstname.equalsIgnoreCase("praveen")) return customer.emailAddress;
	}
	return null;
}

public String getCustomerBooksToSearch(){
	for(UserProfile customer : customerList) {
		if(customer.firstname.equalsIgnoreCase("praveen")) return customer.books;
	}
	return null;
}



}