package com.testautomation.Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.xml.DOMConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchSessionException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.SessionNotCreatedException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.ErrorHandler;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cucumber.listener.Reporter;

public class BaseTest {

	public static WebDriver driver;
	public static Properties prop;
	public static Actions builder;
	public static WebDriverWait wait;

	public BaseTest() {
		DOMConfigurator.configure(".\\src\\test\\resources\\log4j.xml");
		prop = new Properties();
		try {
			prop.load(new FileInputStream("src/test/resources/Configuration.properties"));
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		}
	}

	public static void intialization() {

		String BrowserName = prop.getProperty("browserName");
		if (BrowserName.equalsIgnoreCase("Chrome")) {
			System.setProperty("webdriver.chrome.driver", ".//server//chromedriver.exe");
			driver = new ChromeDriver();
			Log.info("Chrome browser initialized");

		} else if (BrowserName.equalsIgnoreCase("FF")) {
			System.setProperty("webdriver.gecko.driver", "D:\\SeleniumCucumberBDD\\CSTAF\\server\\firefoxdriver.exe");
			driver = new FirefoxDriver();

			Log.info("Firefox browser initialized");

		}
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get(prop.getProperty("appURL"));
		builder = new Actions(driver);
		wait = new WebDriverWait(driver, Integer.parseInt(prop.getProperty("elementWaitTime")));

	}

	public static String getPassword() {
		String loginPwd = prop.getProperty("loginPassword");
		String decodedPwd = StringEncrypt.decryptXOR(loginPwd, "lock");
		return decodedPwd;
	}

	public static void captureScreen(String screenshotName) {

		File screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		try {
			File path = new File(System.getProperty("user.dir") + "/cucumberFolder/cucumber-reports/screenshots/"
					+ screenshotName + ".png");
			FileUtils.copyFile(screenshot, path.getAbsoluteFile());
			Reporter.addScreenCaptureFromPath(path.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static WebDriver chooseDriver(DesiredCapabilities capabilities) {
		final ChromeOptions chromeOptions = new ChromeOptions();
		capabilities.setCapability(ChromeOptions.CAPABILITY, chromeOptions);
		System.out.println("********************* before driver created");
		ChromeDriver driver = new ChromeDriver();
		System.out.println("********************* after driver created");
		ErrorHandler handler = new ErrorHandler();
		handler.setIncludeServerErrors(false);
		driver.setErrorHandler(handler);
		return driver;

	}

	public static void closeDriver() {
		if (driver != null) {
			try {
				driver.close();
				driver.quit();
			} catch (NoSuchMethodError nsme) { // in case quit fails
			} catch (NoSuchSessionException nsse) { // in case close fails
			} catch (SessionNotCreatedException snce) {
			} // in case close fails
			driver = null;
		}
	}

	public void waitForTextToPresent(WebElement element, String textToWait) {

		wait.until(ExpectedConditions.textToBePresentInElement(element, textToWait));
	}

	public void waitForVisibilityOfElement(WebElement element) {
		wait.until(ExpectedConditions.visibilityOf(element));
	}

	public void waitForPresenceOfElement(By by) {
		wait.until(ExpectedConditions.presenceOfElementLocated(by));
	}

	public void elementClick(WebElement element, String info) {
		waitForVisibilityOfElement(element);
		element.click();
		Log.info(info);
	}

	public void elementSendKeysWithClear(WebElement element, String text, String info) {
		waitForVisibilityOfElement(element);
		element.clear();
		element.sendKeys(text);
		Log.info(info);
	}

	public void elementSendKeys(WebElement element, String text, String info) {
		waitForVisibilityOfElement(element);
		element.sendKeys(text);
		Log.info(info);
	}

	public void mouseHover(WebElement element) {
		waitForVisibilityOfElement(element);
		Action mouseOverHome = builder.moveToElement(element).build();
		mouseOverHome.perform();
	}

	public static String getTestDataResourcePath() {
		String path = prop.getProperty("testDataResourcePath");
		return path;
	}

}
